package org.qtproject.example.java;

import android.app.Activity;
import android.graphics.Color;
import android.os.Build;
import android.content.Context;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.view.WindowInsetsController;
import android.util.Log;
import android.view.WindowInsetsController;
import android.view.View;
// import org.qtproject.qt.android.bindings.QtActivity;


public class StatusBarColorChanger {
    public static void changeStatusBarColor(Activity activity, String color, boolean toDark) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = activity.getWindow();
            if(toDark)
                activity.getWindow().getDecorView().getWindowInsetsController().setSystemBarsAppearance(0x00000008, 0x00000008);
            else
                activity.getWindow().getDecorView().getWindowInsetsController().setSystemBarsAppearance(0x00000010, 0x00000010);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.parseColor(color));
        }
    }
}   

