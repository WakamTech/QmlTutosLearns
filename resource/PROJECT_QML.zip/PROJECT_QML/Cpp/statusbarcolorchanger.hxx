#ifndef STATUSBARCOLORCHANGER_HXX
#define STATUSBARCOLORCHANGER_HXX
#include <QObject>

class StatusBarColorChanger : public QObject
{
    Q_OBJECT

public:
    explicit StatusBarColorChanger(QObject *parent = nullptr);

public slots:
    void changeStatusBarColor(const QString &color, bool toDark = false);
};

#endif // STATUSBARCOLORCHANGER_HXX
