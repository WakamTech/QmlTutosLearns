#include <statusbarcolorchanger.hxx>

#ifdef Q_OS_ANDROID
#include <QtCore/private/qandroidextras_p.h>
#include <QJniObject>
#endif

StatusBarColorChanger::StatusBarColorChanger(QObject *parent) : QObject(parent)
{
    changeStatusBarColor("#267EBD");
}

void StatusBarColorChanger::changeStatusBarColor(const QString &color, bool toDark)
{
#ifdef Q_OS_ANDROID
    QNativeInterface::QAndroidApplication::runOnAndroidMainThread([=](){
        QJniObject javaNotification = QJniObject::fromString(color);
        QJniObject::callStaticMethod<void>(
            "org/qtproject/example/java/StatusBarColorChanger",
            "changeStatusBarColor",
            "(Landroid/app/Activity;Ljava/lang/String;Z)V",
            QNativeInterface::QAndroidApplication::context(),
            javaNotification.object<jstring>(),
            jboolean(toDark));
    });
#endif
}
